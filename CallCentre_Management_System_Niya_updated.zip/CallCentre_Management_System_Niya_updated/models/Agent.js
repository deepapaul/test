const mongoose = require("mongoose");

const AgentSchema = new mongoose.Schema({
  agentId: { type: String, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true },
  phoneExtension: { type: String, required: true },
  skillLevel: { type: String, required: true },
  shift: { type: String, required: true }
});

// Auto-generate agentId using timestamp
AgentSchema.pre('save', function() {
  if (!this.agentId) {
    this.agentId = `AGT${Date.now()}`;
  }
});

module.exports = mongoose.model("Agent", AgentSchema);