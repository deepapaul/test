const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
    customerId: {
        type: String,
        unique: true
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String
    },
    address: {
        type: String
    }
});

// Auto-generate customerId using timestamp
customerSchema.pre('save', function() {
    if (!this.customerId) {
        this.customerId = `CUST${Date.now()}`;
    }
});

module.exports = mongoose.model("Customer", customerSchema);