const mongoose = require("mongoose");

const callSchema = new mongoose.Schema({
    callId: {
        type: String,
        unique: true
    },
    customerId: {
        type: String,
        required: true
    },
    agentId: {
        type: String,
        required: true
    },
    startTime: {
        type: Date,
        required: true
    },
    endTime: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    callType: {
        type: String,
        required: true
    }
});

// Auto-generate callId using timestamp
callSchema.pre('save', function() {
    if (!this.callId) {
        this.callId = `CALL${Date.now()}`;
    }
});

module.exports = mongoose.model("Call", callSchema);