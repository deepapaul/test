const mongoose = require("mongoose");

const CallLogSchema = new mongoose.Schema({
  logId: { type: String, unique: true },
  callId: { type: String, required: true },
  logTime: { type: Date, required: true },
  notes: { type: String, required: true }
});

// Auto-generate logId using timestamp
CallLogSchema.pre('save', function() {
  if (!this.logId) {
    this.logId = `LOG${Date.now()}`;
  }
});

module.exports = mongoose.model("CallLog", CallLogSchema);