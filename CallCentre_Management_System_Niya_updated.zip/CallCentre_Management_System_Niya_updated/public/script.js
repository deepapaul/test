/* ================= CUSTOMER ================= */

document.getElementById("customerForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const customer = {
    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value
  };

  if (editingCustomerId) {
    // Update existing customer
    const res = await fetch(`/api/customers/${editingCustomerId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customer)
    });

    if (res.ok) {
      alert("Customer Updated Successfully");
      editingCustomerId = null;
      const submitBtn = this.querySelector("button[type='submit']");
      submitBtn.textContent = "Add Customer";
      submitBtn.style.backgroundColor = "#2c3e50";
    } else {
      alert("Failed to update customer");
      return;
    }
  } else {
    // Add new customer
    const res = await fetch("/api/customers", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(customer)
    });

    await res.json();
    alert("Customer Added Successfully");
  }

  loadCustomers();
  this.reset();
});

async function loadCustomers() {
  const res = await fetch("/api/customers");
  const customers = await res.json();

  const table = document.getElementById("customerTable");
  if (!table) return;

  table.innerHTML = "";

  customers.forEach(c => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${c.customerId || ""}</td>
      <td>${c.name || ""}</td>
      <td>${c.phone || ""}</td>
      <td>${c.email || ""}</td>
      <td>${c.address || ""}</td>
      <td>
        <button class="action-btn edit-btn edit-customer-btn" data-id="${c._id}" data-name="${c.name}" data-phone="${c.phone}" data-email="${c.email}" data-address="${c.address}">✏️</button>
        <button class="action-btn delete-btn delete-customer-btn" data-id="${c._id}">🗑️</button>
      </td>
    `;
  });

  // Add event listeners
  document.querySelectorAll(".edit-customer-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      editCustomer(
        this.dataset.id,
        this.dataset.name,
        this.dataset.phone,
        this.dataset.email,
        this.dataset.address
      );
    });
  });

  document.querySelectorAll(".delete-customer-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      deleteCustomer(this.dataset.id);
    });
  });
}

let editingCustomerId = null;

function editCustomer(id, name, phone, email, address) {
  editingCustomerId = id;
  document.getElementById("name").value = name;
  document.getElementById("phone").value = phone;
  document.getElementById("email").value = email;
  document.getElementById("address").value = address;

  const submitBtn = document.querySelector("#customerForm button[type='submit']");
  submitBtn.textContent = "Update Customer";
  submitBtn.style.backgroundColor = "#f39c12";

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteCustomer(id) {
  if (!confirm("Are you sure you want to delete this customer?")) return;

  try {
    const res = await fetch(`/api/customers/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      alert("Customer deleted successfully");
      loadCustomers();
    } else {
      alert("Failed to delete customer");
    }
  } catch (error) {
    console.error("Delete Error:", error);
    alert("Error deleting customer");
  }
}


/* ================= AGENT ================= */

document.getElementById("agentForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const agent = {
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phoneExtension: document.getElementById("phoneExtension").value,
    skillLevel: document.getElementById("skillLevel").value,
    shift: document.getElementById("shift").value
  };

  if (editingAgentId) {
    // Update existing agent
    const res = await fetch(`/api/agents/${editingAgentId}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(agent)
    });

    if (res.ok) {
      alert("Agent Updated Successfully");
      editingAgentId = null;
      const submitBtn = this.querySelector("button[type='submit']");
      submitBtn.textContent = "Add Agent";
      submitBtn.style.backgroundColor = "#2c3e50";
    } else {
      alert("Failed to update agent");
      return;
    }
  } else {
    // Add new agent
    const res = await fetch("/api/agents", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(agent)
    });

    await res.json();
    alert("Agent Added Successfully");
  }

  loadAgents();
  this.reset();
});

async function loadAgents() {
  const res = await fetch("/api/agents");
  const agents = await res.json();

  const table = document.getElementById("agentTable");
  if (!table) return;

  table.innerHTML = "";

  agents.forEach(a => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${a.agentId || ""}</td>
      <td>${a.name || ""}</td>
      <td>${a.email || ""}</td>
      <td>${a.phoneExtension || ""}</td>
      <td>${a.skillLevel || ""}</td>
      <td>${a.shift || ""}</td>
      <td>
        <button class="action-btn edit-btn edit-agent-btn" data-id="${a._id}" data-name="${a.name}" data-email="${a.email}" data-phone="${a.phoneExtension}" data-skill="${a.skillLevel}" data-shift="${a.shift}">✏️</button>
        <button class="action-btn delete-btn delete-agent-btn" data-id="${a._id}">🗑️</button>
      </td>
    `;
  });

  // Add event listeners
  document.querySelectorAll(".edit-agent-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      editAgent(
        this.dataset.id,
        this.dataset.name,
        this.dataset.email,
        this.dataset.phone,
        this.dataset.skill,
        this.dataset.shift
      );
    });
  });

  document.querySelectorAll(".delete-agent-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      deleteAgent(this.dataset.id);
    });
  });
}

let editingAgentId = null;

function editAgent(id, name, email, phoneExtension, skillLevel, shift) {
  editingAgentId = id;
  document.getElementById("name").value = name;
  document.getElementById("email").value = email;
  document.getElementById("phoneExtension").value = phoneExtension;
  document.getElementById("skillLevel").value = skillLevel;
  document.getElementById("shift").value = shift;

  const submitBtn = document.querySelector("#agentForm button[type='submit']");
  submitBtn.textContent = "Update Agent";
  submitBtn.style.backgroundColor = "#f39c12";

  window.scrollTo({ top: 0, behavior: 'smooth' });
}

async function deleteAgent(id) {
  if (!confirm("Are you sure you want to delete this agent?")) return;

  try {
    const res = await fetch(`/api/agents/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      alert("Agent deleted successfully");
      loadAgents();
    } else {
      alert("Failed to delete agent");
    }
  } catch (error) {
    console.error("Delete Error:", error);
    alert("Error deleting agent");
  }
}

/* ================= CALL ================= */

document.getElementById("callForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const call = {
    customerId: document.getElementById("customerId").value,
    agentId: document.getElementById("agentId").value,
    startTime: document.getElementById("startTime").value,
    endTime: document.getElementById("endTime").value,
    status: document.getElementById("status").value,
    callType: document.getElementById("callType").value
  };

  await fetch("/api/calls", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(call)
  });

  alert("Call Added Successfully");
  loadCalls();
  this.reset();
});

async function loadCalls() {
  const res = await fetch("/api/calls");
  const calls = await res.json();

  const table = document.getElementById("callTable");
  if (!table) return;

  table.innerHTML = "";

  calls.forEach(c => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${c.callId || ""}</td>
      <td>${c.agentId || ""}</td>
      <td>${c.customerId || ""}</td>
      <td>${c.startTime || ""}</td>
      <td>${c.endTime || ""}</td>
      <td>${c.status || ""}</td>
      <td>${c.callType || ""}</td>
      <td>
        <button class="action-btn delete-btn delete-call-btn" data-id="${c._id}">🗑️</button>
      </td>
    `;
  });

  // Add event listeners
  document.querySelectorAll(".delete-call-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      deleteCall(this.dataset.id);
    });
  });
}

async function deleteCall(id) {
  if (!confirm("Are you sure you want to delete this call?")) return;

  try {
    const res = await fetch(`/api/calls/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      alert("Call deleted successfully");
      loadCalls();
    } else {
      alert("Failed to delete call");
    }
  } catch (error) {
    console.error("Delete Error:", error);
    alert("Error deleting call");
  }
}

/* ================= TICKET ================= */

document.getElementById("ticketForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const ticket = {
    agentId: document.getElementById("agentId").value,
    customerId: document.getElementById("customerId").value,
    issueDesc: document.getElementById("issueDesc").value,
    priority: document.getElementById("priority").value,
    status: document.getElementById("status").value,
    createdDate: document.getElementById("createdDate").value
  };

  await fetch("/api/tickets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ticket)
  });

  alert("Ticket Added Successfully");
  loadTickets();
  this.reset();
});

async function loadTickets() {
  const res = await fetch("/api/tickets");
  const tickets = await res.json();

  const table = document.getElementById("ticketTable");
  if (!table) return;

  table.innerHTML = "";

  tickets.forEach(t => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${t.ticketId || ""}</td>
      <td>${t.agentId || ""}</td>
      <td>${t.customerId || ""}</td>
      <td>${t.issueDesc || ""}</td>
      <td>${t.priority || ""}</td>
      <td>${t.status || ""}</td>
      <td>${t.createdDate || ""}</td>
      <td>
        <button class="action-btn delete-btn delete-ticket-btn" data-id="${t._id}">🗑️</button>
      </td>
    `;
  });

  // Add event listeners
  document.querySelectorAll(".delete-ticket-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      deleteTicket(this.dataset.id);
    });
  });
}

async function deleteTicket(id) {
  if (!confirm("Are you sure you want to delete this ticket?")) return;

  try {
    const res = await fetch(`/api/tickets/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      alert("Ticket deleted successfully");
      loadTickets();
    } else {
      alert("Failed to delete ticket");
    }
  } catch (error) {
    console.error("Delete Error:", error);
    alert("Error deleting ticket");
  }
}

/* ================= CALL LOG ================= */

document.getElementById("callLogForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const log = {
    callId: document.getElementById("callId").value,
    logTime: document.getElementById("logTime").value,
    notes: document.getElementById("notes").value
  };

  await fetch("/api/calllogs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(log)
  });

  alert("Call Log Added Successfully");
  loadCallLogs();
  this.reset();
});

async function loadCallLogs() {
  const res = await fetch("/api/calllogs");
  const logs = await res.json();

  const table = document.getElementById("callLogTable");
  if (!table) return;

  table.innerHTML = "";

  logs.forEach(l => {
    const row = table.insertRow();
    row.innerHTML = `
      <td>${l.logId || ""}</td>
      <td>${l.callId || ""}</td>
      <td>${l.logTime || ""}</td>
      <td>${l.notes || ""}</td>
      <td>
        <button class="action-btn delete-btn delete-calllog-btn" data-id="${l._id}">🗑️</button>
      </td>
    `;
  });

  // Add event listeners
  document.querySelectorAll(".delete-calllog-btn").forEach(btn => {
    btn.addEventListener("click", function() {
      deleteCallLog(this.dataset.id);
    });
  });
}

async function deleteCallLog(id) {
  if (!confirm("Are you sure you want to delete this call log?")) return;

  try {
    const res = await fetch(`/api/calllogs/${id}`, {
      method: "DELETE"
    });

    if (res.ok) {
      alert("Call log deleted successfully");
      loadCallLogs();
    } else {
      alert("Failed to delete call log");
    }
  } catch (error) {
    console.error("Delete Error:", error);
    alert("Error deleting call log");
  }
}