const express = require("express");
const mongoose = require("mongoose");
const path = require("path");

const Agent = require("./models/Agent");
const Customer = require("./models/Customer");
const Call = require("./models/Call");
const Ticket = require("./models/Ticket");
const CallLog = require("./models/CallLog");

const app = express();

/* ================= MIDDLEWARE ================= */

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

/* ================= MONGODB CONNECTION ================= */

mongoose.connect("mongodb://127.0.0.1:27017/callcentreDB_new")
.then(() => console.log("✅ MongoDB Connected Successfully"))
.catch(err => console.log("❌ MongoDB Connection Error:", err));

/* ================= ROUTES ================= */

/* ---------- AGENT ---------- */

app.post("/api/agents", async (req, res) => {
  try {
    const agent = new Agent(req.body);
    await agent.save();
    res.status(201).json(agent);
  } catch (error) {
    console.error("Agent Save Error:", error);
    res.status(500).json({ error: "Failed to save agent" });
  }
});

app.get("/api/agents", async (req, res) => {
  try {
    const agents = await Agent.find();
    res.json(agents);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch agents" });
  }
});

/* ---------- CUSTOMER ---------- */

app.post("/api/customers", async (req, res) => {
  try {
    const customer = new Customer(req.body);
    console.log('here');
    await customer.save();
    res.status(201).json(customer);
  } catch (error) {
    console.error("Customer Save Error:", error);
    res.status(500).json({ error: "Failed to save customer" });
  }
});

app.get("/api/customers", async (req, res) => {
  try {
    const customers = await Customer.find();
    res.json(customers);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch customers" });
  }
});

/* ---------- CALL ---------- */

app.post("/api/calls", async (req, res) => {
  try {
    const call = new Call(req.body);
    await call.save();
    res.status(201).json(call);
  } catch (error) {
    console.error("Call Save Error:", error);
    res.status(500).json({ error: "Failed to save call" });
  }
});

app.get("/api/calls", async (req, res) => {
  try {
    const calls = await Call.find();
    res.json(calls);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch calls" });
  }
});

/* ---------- TICKET ---------- */

app.post("/api/tickets", async (req, res) => {
  try {
    const ticket = new Ticket(req.body);
    await ticket.save();
    res.status(201).json(ticket);
  } catch (error) {
    console.error("Ticket Save Error:", error);
    res.status(500).json({ error: "Failed to save ticket" });
  }
});

app.get("/api/tickets", async (req, res) => {
  try {
    const tickets = await Ticket.find();
    res.json(tickets);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch tickets" });
  }
});

/* ---------- CALL LOG ---------- */

app.post("/api/calllogs", async (req, res) => {
  try {
    const log = new CallLog(req.body);
    await log.save();
    res.status(201).json(log);
  } catch (error) {
    console.error("CallLog Save Error:", error);
    res.status(500).json({ error: "Failed to save call log" });
  }
});

app.get("/api/calllogs", async (req, res) => {
  try {
    const logs = await CallLog.find();
    res.json(logs);
  } catch (error) {
    res.status(500).json({ error: "Failed to fetch call logs" });
  }
});

/* ================= SERVER ================= */

const PORT = 3000;

app.listen(PORT, () => {
  console.log(`🚀 Server running on http://localhost:${PORT}`);
});