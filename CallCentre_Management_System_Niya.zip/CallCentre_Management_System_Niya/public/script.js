/* ================= CUSTOMER ================= */

document.getElementById("customerForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const customer = {
    customerId: document.getElementById("customerId").value,
    name: document.getElementById("name").value,
    phone: document.getElementById("phone").value,
    email: document.getElementById("email").value,
    address: document.getElementById("address").value
  };

  const res = await fetch("/api/customers", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(customer)
  });

  await res.json();
  alert("Customer Added Successfully");

  loadCustomers();
  this.reset();
});

async function loadCustomers() {
  const res = await fetch("/api/customers");
  const customers = await res.json();

  const table = document.getElementById("customerTable");
  if (!table) return;

  table.innerHTML = "";

  customers.forEach(c => {
    table.innerHTML += `
      <tr>
        <td>${c.customerId || ""}</td>
        <td>${c.name || ""}</td>
        <td>${c.phone || ""}</td>
        <td>${c.email || ""}</td>
        <td>${c.address || ""}</td>
      </tr>
    `;
  });
}


/* ================= AGENT ================= */

document.getElementById("agentForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const agent = {
    agentId: document.getElementById("agentId").value,
    name: document.getElementById("name").value,
    email: document.getElementById("email").value,
    phoneExtension: document.getElementById("phoneExtension").value,
    skillLevel: document.getElementById("skillLevel").value,
    shift: document.getElementById("shift").value
  };

  const res = await fetch("/api/agents", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(agent)
  });

  await res.json();
  alert("Agent Added Successfully");

  loadAgents();
  this.reset();
});

async function loadAgents() {
  const res = await fetch("/api/agents");
  const agents = await res.json();

  const table = document.getElementById("agentTable");
  if (!table) return;

  table.innerHTML = "";

  agents.forEach(a => {
    table.innerHTML += `
      <tr>
        <td>${a.agentId || ""}</td>
        <td>${a.name || ""}</td>
        <td>${a.email || ""}</td>
        <td>${a.phoneExtension || ""}</td>
        <td>${a.skillLevel || ""}</td>
        <td>${a.shift || ""}</td>
      </tr>
    `;
  });
}

/* ================= CALL ================= */

document.getElementById("callForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const call = {
    callId: document.getElementById("callId").value,
    customerId: document.getElementById("customerId").value,
    agentId: document.getElementById("agentId").value,
    startTime: document.getElementById("startTime").value,
    endTime: document.getElementById("endTime").value,
    status: document.getElementById("status").value,
    callType: document.getElementById("callType").value
  };

  await fetch("/api/calls", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(call)
  });

  alert("Call Added Successfully");
  loadCalls();
  this.reset();
});

async function loadCalls() {
  const res = await fetch("/api/calls");
  const calls = await res.json();

  const table = document.getElementById("callTable");
  if (!table) return;

  table.innerHTML = "";

  calls.forEach(c => {
    table.innerHTML += `
      <tr>
        <td>${c.callId || ""}</td>
        <td>${c.agentId || ""}</td>
        <td>${c.customerId || ""}</td>
        <td>${c.startTime || ""}</td>
        <td>${c.endTime || ""}</td>
        <td>${c.status || ""}</td>
        <td>${c.callType || ""}</td>
      </tr>
    `;
  });
}

/* ================= TICKET ================= */

document.getElementById("ticketForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const ticket = {
    ticketId: document.getElementById("ticketId").value,
    agentId: document.getElementById("agentId").value,
    customerId: document.getElementById("customerId").value,
    issueDesc: document.getElementById("issueDesc").value,
    priority: document.getElementById("priority").value,
    status: document.getElementById("status").value,
    createdDate: document.getElementById("createdDate").value
  };

  await fetch("/api/tickets", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(ticket)
  });

  alert("Ticket Added Successfully");
  loadTickets();
  this.reset();
});

async function loadTickets() {
  const res = await fetch("/api/tickets");
  const tickets = await res.json();

  const table = document.getElementById("ticketTable");
  if (!table) return;

  table.innerHTML = "";

  tickets.forEach(t => {
    table.innerHTML += `
      <tr>
        <td>${t.ticketId || ""}</td>
        <td>${t.agentId || ""}</td>
        <td>${t.customerId || ""}</td>
        <td>${t.issueDesc || ""}</td>
        <td>${t.priority || ""}</td>
        <td>${t.status || ""}</td>
        <td>${t.createdDate || ""}</td>
      </tr>
    `;
  });
}

/* ================= CALL LOG ================= */

document.getElementById("callLogForm")?.addEventListener("submit", async function (e) {
  e.preventDefault();

  const log = {
    logId: document.getElementById("logId").value,
    callId: document.getElementById("callId").value,
    logTime: document.getElementById("logTime").value,
    notes: document.getElementById("notes").value
  };

  await fetch("/api/calllogs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(log)
  });

  alert("Call Log Added Successfully");
  loadCallLogs();
  this.reset();
});

async function loadCallLogs() {
  const res = await fetch("/api/calllogs");
  const logs = await res.json();

  const table = document.getElementById("callLogTable");
  if (!table) return;

  table.innerHTML = "";

  logs.forEach(l => {
    table.innerHTML += `
      <tr>
        <td>${l.logId || ""}</td>
        <td>${l.callId || ""}</td>
        <td>${l.logTime || ""}</td>
        <td>${l.notes || ""}</td>
      </tr>
    `;
  });
}