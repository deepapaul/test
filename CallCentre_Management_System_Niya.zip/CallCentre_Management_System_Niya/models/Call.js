const mongoose = require("mongoose");

const callSchema = new mongoose.Schema({
    callId: {
        type: String,
        required: true
    },
    customerId: {
        type: String,
        required: true
    },
    agentId: {
        type: String,
        required: true
    },
    startTime: {
        type: Date,
        required: true
    },
    endTime: {
        type: Date,
        required: true
    },
    status: {
        type: String,
        required: true
    },
    callType: {
        type: String,
        required: true
    }
});

module.exports = mongoose.model("Call", callSchema);