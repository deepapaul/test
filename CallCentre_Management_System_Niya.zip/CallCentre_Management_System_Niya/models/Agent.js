const mongoose = require("mongoose");

const AgentSchema = new mongoose.Schema({
  agentId: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  email: { type: String, required: true },
  phoneExtension: { type: String, required: true },
  skillLevel: { type: String, required: true },
  shift: { type: String, required: true }
});

module.exports = mongoose.model("Agent", AgentSchema);