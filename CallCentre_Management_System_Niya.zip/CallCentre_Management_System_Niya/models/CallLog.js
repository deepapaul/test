const mongoose = require("mongoose");

const CallLogSchema = new mongoose.Schema({
  logId: { type: String, required: true, unique: true },
  callId: { type: String, required: true },
  logTime: { type: Date, required: true },
  notes: { type: String, required: true }
});

module.exports = mongoose.model("CallLog", CallLogSchema);