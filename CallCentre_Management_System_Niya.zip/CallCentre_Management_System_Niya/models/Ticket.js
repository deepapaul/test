const mongoose = require("mongoose");

const TicketSchema = new mongoose.Schema({
  ticketId: { type: String, required: true, unique: true },
  agentId: { type: String, required: true },
  customerId: { type: String, required: true },
  issueDesc: { type: String, required: true },
  priority: { type: String, required: true },
  status: { type: String, required: true },
  createdDate: { type: Date, required: true }
});

module.exports = mongoose.model("Ticket", TicketSchema);