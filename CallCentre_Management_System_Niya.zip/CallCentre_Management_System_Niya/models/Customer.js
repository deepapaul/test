const mongoose = require("mongoose");

const customerSchema = new mongoose.Schema({
    customerId: {
        type: String,
        required: true
    },
    name: {
        type: String,
        required: true
    },
    phone: {
        type: String,
        required: true
    },
    email: {
        type: String
    },
    address: {
        type: String
    }
});

module.exports = mongoose.model("Customer", customerSchema);